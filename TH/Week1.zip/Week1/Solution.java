public class Solution {
    public long fibonacci(long n) {
        if(n < 0) return -1;
        if(n == 0) return 0;
        if(n == 1) return 1;

        long F0 = 0, F1 = 1;
        for(int i = 2; i <= n; ++i) {
            if(F0 >= Long.MAX_VALUE - F1)
                return Long.MAX_VALUE;

            Long F2 = F0 + F1;
            F0 = F1;
            F1 = F2;
        }
        return F1;
    }

    public int gcd(int a, int b) {
        if(b == 0) return a;
        return gcd(b, a % b);
    }

    public boolean isPrime(int n) {
        for(int i = 2; i < n; ++i)
            if(n % i == 0)
                return false;
        return true;
    }

    public int reverse(int n) {
        int m = 0;
        while(n > 0) {
            m = m * 10 + n % 10;
            n /= 10;
        }
        return m;
    }

    public boolean isPalindrome(int n) {
        return reverse(n) == n;
    }

    public int sumOfDigits(int n) {
        int SumDig = 0;
        while(n > 0) {
            SumDig += n % 10;
            n /= 10;
        }
        return SumDig;
    }

    public int secondLargest(int[] arr) {
        int Large1 = Integer.MIN_VALUE, Large2 = Integer.MIN_VALUE;
        for(int x : arr) {
            if(x > Large1) {
                Large2 = Large1;
                Large1 = x;
            }
            else if(x < Large1 && x > Large2)
                Large2 = x;
        }
        if(Large2 == Integer.MIN_VALUE)
            return -1;
        return Large2;
    }

    public static void main(String[] args) {
        Solution Main = new Solution();
        System.out.println(Main.fibonacci(100));
        System.out.println(Main.gcd(6, 3));
        System.out.println(Main.isPrime(7));
        System.out.println(Main.reverse(452452));
        System.out.println(Main.isPalindrome(123321));
        System.out.println(Main.sumOfDigits(234));
        System.out.println(Main.secondLargest(new int[]{1, 2, 2, 3, 3}));
    }
}
